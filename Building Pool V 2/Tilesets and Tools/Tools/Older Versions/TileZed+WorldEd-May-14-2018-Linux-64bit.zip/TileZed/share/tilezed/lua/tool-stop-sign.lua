params = {}
params.undoText = 'Stop Sign'
params.layer0 = '0_Furniture'
params.tile0 = { w = 'street_decoration_01_3',
                 n = 'street_decoration_01_2',
                 e = 'street_decoration_01_1',
                 s = 'street_decoration_01_0' }

dofile(scriptDirectory..'/tool-four-directions.lua')

