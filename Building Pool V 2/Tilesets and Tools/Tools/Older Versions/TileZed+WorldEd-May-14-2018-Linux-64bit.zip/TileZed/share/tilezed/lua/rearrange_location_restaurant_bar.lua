local tiles = ""
tiles = tiles .. "location_restaurant_bar_01_16;location_restaurant_bar_01_44;"
tiles = tiles .. "location_restaurant_bar_01_17;location_restaurant_bar_01_45;"
tiles = tiles .. "location_restaurant_bar_01_18;location_restaurant_bar_01_46;"
tiles = tiles .. "location_restaurant_bar_01_19;location_restaurant_bar_01_52;"
tiles = tiles .. "location_restaurant_bar_01_20;location_restaurant_bar_01_53;"
tiles = tiles .. "location_restaurant_bar_01_21;location_restaurant_bar_01_54;"
tiles = tiles .. "location_restaurant_bar_01_22;location_restaurant_bar_01_55;"
tiles = tiles .. "location_restaurant_bar_01_23;location_restaurant_bar_01_47;"

map:replaceTilesByName(tiles)

