local tiles = ""
tiles = tiles .. "floors_exterior_street_01_12;blends_street_01_96;"
tiles = tiles .. "floors_exterior_street_01_13;blends_street_01_96;"
tiles = tiles .. "floors_exterior_street_01_14;blends_street_01_96;"

map:replaceTilesByName(tiles)

