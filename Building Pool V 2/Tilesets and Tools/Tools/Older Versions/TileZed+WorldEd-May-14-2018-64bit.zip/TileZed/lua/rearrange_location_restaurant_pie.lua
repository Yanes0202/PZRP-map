local tiles = ""
tiles = tiles .. "location_restaurant_pie_01_54;location_restaurant_pie_01_55;"
tiles = tiles .. "location_restaurant_pie_01_55;location_restaurant_pie_01_54;"
tiles = tiles .. "location_restaurant_pie_01_8;location_restaurant_pie_01_5;"
tiles = tiles .. "location_restaurant_pie_01_14;location_restaurant_pie_01_10;"
tiles = tiles .. "location_restaurant_pie_01_15;location_restaurant_pie_01_11;"
tiles = tiles .. "location_restaurant_pie_01_22;location_restaurant_pie_01_14;"
tiles = tiles .. "location_restaurant_pie_01_23;location_restaurant_pie_01_15;"

map:replaceTilesByName(tiles)

