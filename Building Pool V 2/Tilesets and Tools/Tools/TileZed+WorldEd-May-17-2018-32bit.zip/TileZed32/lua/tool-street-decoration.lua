DATA = {}
function add4d(f) DATA[#DATA+1] = f end
loadToolData 'street-decoration'

dofile(scriptDirectory..'/tool-four-directions.lua')
