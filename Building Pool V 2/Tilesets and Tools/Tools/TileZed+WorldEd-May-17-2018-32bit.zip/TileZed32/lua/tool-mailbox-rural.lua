params = {}
params.undoText = 'Mailbox (Rural)'
params.layer0 = '0_Furniture'
params.tile0 = { w = 'street_decoration_01_20',
                 n = 'street_decoration_01_21',
                 e = 'street_decoration_01_18',
                 s = 'street_decoration_01_19' }

dofile(scriptDirectory..'/tool-four-directions.lua')

